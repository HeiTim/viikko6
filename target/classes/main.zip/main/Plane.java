package main;

public class Plane extends Vehicle {
    public Plane(String manufacturer, String model, int maxSpeed ){
        super("Lentokone", manufacturer, model, maxSpeed);
       
        

    }
    public void fly(){
        System.out.println(manufacturer + " " + model + " lentää kohteeseen!");
    }
    
}
